# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/opt/Xilinx/Vivado/2019.1/bin/vivado  -notrace -mode batch -source run_ippack.tcl

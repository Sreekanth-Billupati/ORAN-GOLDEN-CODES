#!/bin/sh
# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# ==============================================================
# The next line restarts using autoesl tclsh \
    exec /opt/Xilinx/Vivado/2019.1/bin/vivado_hls run_sim.tcl

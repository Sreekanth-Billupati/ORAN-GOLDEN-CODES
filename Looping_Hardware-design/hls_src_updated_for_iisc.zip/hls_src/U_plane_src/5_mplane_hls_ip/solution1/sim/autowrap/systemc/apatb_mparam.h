// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_mparam (
hls::stream<ap_uint<64> > (&indata),
hls::stream<struct ethdata > (&out1data),
hls::stream<ap_uint<16> > (&out2data));
